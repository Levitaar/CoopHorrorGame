﻿using System;

namespace Application
{
	public class xyObject
	{
		public string y;
		public string x;
		public xyObject ()
		{
		}
	}
}

