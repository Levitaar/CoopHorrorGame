﻿using UnityEngine;
using System.Collections;

public class ToSelectScene : MonoBehaviour {


	void Start () {
	
	}

	void Update () {
	
	
	}
}
