﻿using UnityEngine;
using System.Collections;
using UnityEngine.Networking;

public class PrefabSelector : NetworkManager {

	public override void OnServerConnect(NetworkConnection conn) {

		print ("player connected");

	

	}

}
